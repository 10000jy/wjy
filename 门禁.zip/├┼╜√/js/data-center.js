$(function() {
    var total_register = echarts.init(document.getElementById('total-registration'));
    var total_owner = echarts.init(document.getElementById('total-owner'));
    //注册总数
    total_register.setOption({
        title: {
            text: '注册总数',
            x: "center"
        },
        tooltip: {
            trigger: 'item',
            formatter: '{a}<br/>{b}:{c}({d}%)'

        },
        legend: {
            type: 'scroll',
            data: [],
            left: "left"
        },
        series: [{
                name: '人数',
                type: 'pie',
                data: []
            }

        ]
    });
    total_register.showLoading();
    // Ajax请求数据
    $.ajax({
        type: "get",
        url: "test.json",
        success: function(data) {

            total_register.hideLoading();
            // 填入数据
            total_register.setOption({
                legend: {

                    data: data,
                    left: "left",
                    orient: 'vertical'
                },
                series: [{
                        // 根据名字对应到相应的系列
                        name: '人数',
                        data: data,
                        itemStyle: {
                        normal: {
                            label: {
                                show: true,
                                formatter: '{b} : {c} ({d}%)'
                            },
                            labelLine: {
                                show: true
                            }
                        }
                    }
                    }

                ]
            });
        }
    });
    //已通过审核业主总数
    total_owner.setOption({
        title: {
            text: '已通过审核业主总数',
            x: "center"
        },
        tooltip: {
            trigger: 'item',
            formatter: "{a} <br/>{b} : {c} ({d}%)"
        },
        legend: {
            type: 'scroll',
            data: [],
            left: "left"
        },
        series: [{
            name: '人数',
            type: 'pie',
            data: []
        }]
    });
    total_owner.showLoading();
    // Ajax请求数据
    $.ajax({
        type: "get",
        url: "test2.json",
        success: function(data) {
            total_owner.hideLoading();
            // 填入数据
            total_owner.setOption({
                legend: {
                    data:data,
                    left: "left",
                    orient: 'vertical'
                },
                series: [{
                    // 根据名字对应到相应的系列
                    name: '人数',
                    data: data,
                    itemStyle: {
                        normal: {
                            label: {
                                show: true,
                                formatter: '{b} : {c} ({d}%)'
                            },
                            labelLine: {
                                show: true
                            }
                        }
                    }
                }]
            });
        }
    })
})